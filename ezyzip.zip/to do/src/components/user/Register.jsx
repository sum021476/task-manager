import React, { useState } from 'react'
import { Services } from '../services/Services'
import styles from "./RegisterForm.module.css";
const Register = () => {
    let [state,setState]=useState({
        email:"",
        password:"",
        gender:""
    })
    let [check,setCheck]=useState([])
    let handleCheck=(e)=>{
        let {checked,value}=e.target     
        checked?setCheck((preval)=>([...preval,value])):setCheck   
    }
    let handleChange=(e)=>{
        let{name,value}=e.target
        setState({...state,[name]:value})
    }
    let handleSubmit=(e)=>{
        e.preventDefault()
        try {
            let{email,password,gender}=state
            let payload={email,password,gender,check}
        Services.registerUser(payload)
        } catch (error) {
            console.log("invalid")
        }
    }
  return (
    <>
     <form onSubmit={handleSubmit} className={styles.registerForm}>
        <div>
            <label htmlFor="email">Email:</label>
            <input type='email' id='email' name='email' 
            onChange={handleChange}/>
        </div>
        <div>
            <label htmlFor="password">Password:</label>
            <input type="password" name="password" id="pasword" onChange={handleChange} />
        </div>
        <div onChange={handleChange}>
            <label htmlFor="gender">Gender:</label>
            <input type="radio" id='male' name='gender' value="male"/>Male
            <input type="radio" id='female' name='gender' value="female" />Female
        </div>
        <div>
            <label htmlFor="skills">Skills:</label>
        <div value="skills" onChange={handleCheck} name="skills">
        <input type="checkbox" id='html' value="html" name='skills'/>html
            <input type="checkbox" id="css" value="css" name='skills'/>css
            <input type="checkbox" id='js' value="js" name='skills'/>js
            <input type="checkbox" id='react' value="react" name='skills'/>react
            <input type="checkbox" id='core java' value="react" name='skills'/> core java
        </div>
        </div>
        <div>
                <input type="submit" value="register"/>
        </div>
    </form> 
    </>
  )
}

export default Register
