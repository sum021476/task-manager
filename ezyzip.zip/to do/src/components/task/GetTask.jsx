import React, { useContext, useEffect, useState } from "react";
import { ContextApi } from "../context/Context";
import { Services } from "../services/Services";
import styles from  "./GetTask.module.css";
import { Link, useNavigate } from "react-router-dom";

const GetTask = () => {
  let navigate=useNavigate()
  let { globalState,setGlobalState} = useContext(ContextApi);
  let [state, setState] = useState([]);
  console.log(globalState.id)
  useEffect(()=>{
    (async()=>{
      let {data}=await Services.getTaskUser(globalState.id)
      // console.log("Data:",data)
      setState(data)
    })()
},[state.length])
let handleClick=()=>{
navigate("/Creation")
}
let handleDeleteClick=(id)=>{
    (async()=>{
      let data= Services.deleteTaskUser(id)
    console.log(data)
    setState(state.filter((val)=>{val.id!=data.id}))
    })()  
}
let handleLogoutClick=()=>{
  sessionStorage.removeItem("Token")
  navigate("/UpdateTask")
}
  return (
    <div className={styles.mainContainer}>
    {
      state.length?state.map((val,ind)=>{
        return(
          <div key={ind} className={styles.card}>
            <h3>{val.title}</h3>
            <h4>{val.content}</h4>
            <button className={styles.updateBtn} ><Link to={"/updateTask"} state={{...val}}>update</Link></button>
            <button className={styles.deleteBtn} onClick={()=>{
              handleDeleteClick(val.id)
            }}>Delete</button>
          </div>
        )
      }):<h3>"loading..."</h3>  
}
        <button onClick={handleClick}>+</button>
        <button onClick={handleLogoutClick}>Logout</button>
   </div>
    
  );
};

export default GetTask;
